# toko-online-sederhana

1. usename: admin
2. password: admin

## info
1. php native 7.x
2. bootstrap 4
2. theme admin by sbadmin2 + sweetalert2

## catatan
besifat open source, bebas diubah. tapi jangan ngaku ngaku punya elu
ada pertanyaan hub wa: 0895611024559(fajar)

### kredit
Dev. Fajar Rivaldi Chan | Powered By Chanofficial

![image](https://user-images.githubusercontent.com/69442735/104312503-45db5200-5509-11eb-9be9-c8c6960893b8.png)
![image](https://user-images.githubusercontent.com/69442735/104312597-67d4d480-5509-11eb-99eb-4c38f5633b21.png)
landing page

![image](https://user-images.githubusercontent.com/69442735/104312651-7c18d180-5509-11eb-9e8e-4363850ae4d4.png)
![image](https://user-images.githubusercontent.com/69442735/104312892-d2861000-5509-11eb-848b-c00256ee4f34.png)
 admin
